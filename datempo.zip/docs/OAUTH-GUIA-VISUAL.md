# 🖼️ Guia Visual - OAuth Google Console (DaTempo)

> Guia passo a passo com representações visuais da interface do Google

---

## 📍 Passo 1: Acessar Google Cloud Console

```
🌐 URL: https://console.cloud.google.com/apis/credentials
```

---

## 📍 Passo 2: Tela "Criar ID do Cliente OAuth"

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Criar ID do cliente do OAuth                               ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ Um ID do cliente é usado para identificar um único app     ┃
┃ nos servidores OAuth do Google.                            ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Tipo de aplicativo                                   │   ┃
┃ │                                                       │   ┃
┃ │ ( ) Aplicativo de computador                         │   ┃
┃ │ ( ) Aplicativo para Android                          │   ┃
┃ │ ( ) Aplicativo para iOS                              │   ┃
┃ │ (●) Aplicativo da Web                    ← ESCOLHA   │   ┃
┃ │ ( ) Identificação Universal (do Servidor)            │   ┃
┃ │ ( ) TV e dispositivos com entrada limitada           │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Nome                                                 │   ┃
┃ │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │   ┃
┃ │ ┃ DaTempo OAuth Client                          ┃ │   ┃
┃ │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │   ┃
┃ │                                                       │   ┃
┃ │ O nome do cliente OAuth 2.0. Esse nome é usado      │   ┃
┃ │ apenas para identificar o cliente no console.        │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

---

## 📍 Passo 3: Origens JavaScript Autorizadas

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Origens JavaScript autorizadas                             ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ Para usar com solicitações de um navegador                 ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ URIs                                                 │   ┃
┃ │                                                       │   ┃
┃ │ 1  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │   ┃
┃ │    ┃ https://zapagenda.vercel.app              ┃  │   ┃
┃ │    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │   ┃
┃ │                                                       │   ┃
┃ │ 2  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │   ┃
┃ │    ┃ http://localhost:3000                     ┃  │   ┃
┃ │    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │   ┃
┃ │                                                       │   ┃
┃ │    [+ Adicionar URI]                                 │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ⚠️ IMPORTANTE:                                             ┃
┃ • Apenas a origem (sem /api ou outros paths)              ┃
┃ • HTTPS em produção, HTTP apenas em localhost             ┃
┃ • Não deixe vazio (causa erro)                            ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

### ✅ Exemplos CORRETOS:
```
✓ https://zapagenda.vercel.app
✓ https://www.datempo.com.br
✓ http://localhost:3000
```

### ❌ Exemplos ERRADOS:
```
✗ https://zapagenda.vercel.app/        (barra no final)
✗ https://zapagenda.vercel.app/api     (com path)
✗ zapagenda.vercel.app                 (sem https://)
✗ (vazio)                               (não preencher causa erro)
```

---

## 📍 Passo 4: URIs de Redirecionamento

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ URIs de redirecionamento autorizados                       ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ Para usar com solicitações de um servidor da Web           ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ URIs                                                 │   ┃
┃ │                                                       │   ┃
┃ │ 1  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │   ┃
┃ │    ┃ https://zapagenda.vercel.app/api/google/  ┃  │   ┃
┃ │    ┃ oauth/callback                            ┃  │   ┃
┃ │    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │   ┃
┃ │                                                       │   ┃
┃ │ 2  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓  │   ┃
┃ │    ┃ http://localhost:3000/api/google/oauth/   ┃  │   ┃
┃ │    ┃ callback                                  ┃  │   ┃
┃ │    ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛  │   ┃
┃ │                                                       │   ┃
┃ │    [+ Adicionar URI]                                 │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ℹ️ NOTA: Pode levar de 5 minutos a algumas horas para     ┃
┃   que as configurações entrem em vigor                     ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

### ✅ Exemplos CORRETOS:
```
✓ https://zapagenda.vercel.app/api/google/oauth/callback
✓ https://www.datempo.com.br/api/google/oauth/callback
✓ http://localhost:3000/api/google/oauth/callback
```

### ❌ Exemplos ERRADOS:
```
✗ https://zapagenda.vercel.app/api/google/oauth/callback/  (barra extra)
✗ https://zapagenda.vercel.app/api/google/callback         (sem /oauth/)
✗ https://zapagenda.vercel.app                              (sem o path)
✗ zapagenda.vercel.app/api/google/oauth/callback           (sem https://)
```

---

## 📍 Passo 5: Criar e Copiar Credenciais

Após clicar em **"Criar"**, você verá:

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Cliente OAuth criado                                       ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ Aqui está o ID do cliente e o secret do cliente.          ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ ID do cliente                                        │   ┃
┃ │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │   ┃
┃ │ ┃ 123456789-abc123.apps.googleusercontent.com ┃ │   ┃
┃ │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │   ┃
┃ │                                            [📋 Copiar]│   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Secret do cliente                                    │   ┃
┃ │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │   ┃
┃ │ ┃ GOCSPX-abc123xyz456...                       ┃ │   ┃
┃ │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │   ┃
┃ │                                            [📋 Copiar]│   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃                                 [OK]      [Fazer download] ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

**📋 Copie ambos** (clique nos botões [📋 Copiar])

---

## 📍 Passo 6: Configurar no Vercel

```
🌐 URL: https://vercel.com/seu-projeto/settings/environment-variables
```

Adicione uma variável por vez:

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Environment Variables                                      ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Key (Nome)                                           │   ┃
┃ │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │   ┃
┃ │ ┃ GOOGLE_CLIENT_ID                              ┃ │   ┃
┃ │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Value (Valor)                                        │   ┃
┃ │ ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓ │   ┃
┃ │ ┃ 123456789-abc123.apps.googleusercontent.com ┃ │   ┃
┃ │ ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛ │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃ ┌─────────────────────────────────────────────────────┐   ┃
┃ │ Environment                                          │   ┃
┃ │                                                       │   ┃
┃ │ [✓] Production                                       │   ┃
┃ │ [ ] Preview                                          │   ┃
┃ │ [ ] Development                                      │   ┃
┃ └─────────────────────────────────────────────────────┘   ┃
┃                                                             ┃
┃                                              [Add Variable] ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

Repita para:
- `GOOGLE_CLIENT_SECRET` → (o secret que copiou)
- `APP_BASE_URL` → `https://zapagenda.vercel.app`

---

## 📍 Passo 7: Fluxo de Teste

```
Usuário                  DaTempo                 Google
  │                         │                       │
  │  1. Acessa configurações │                       │
  ├─────────────────────────>│                       │
  │                         │                       │
  │  2. Clica "Conectar     │                       │
  │     Google Calendar"    │                       │
  ├─────────────────────────>│                       │
  │                         │                       │
  │                         │  3. Redireciona com   │
  │                         │     Client ID         │
  │                         ├──────────────────────>│
  │                         │                       │
  │  4. Tela de autorização Google                 │
  │<──────────────────────────────────────────────┤
  │                         │                       │
  │  5. Usuário autoriza    │                       │
  ├──────────────────────────────────────────────>│
  │                         │                       │
  │                         │  6. Retorna com code  │
  │                         │<──────────────────────┤
  │                         │                       │
  │                         │  7. Troca code por    │
  │                         │     access token      │
  │                         ├──────────────────────>│
  │                         │                       │
  │                         │  8. Retorna token     │
  │                         │<──────────────────────┤
  │                         │                       │
  │  9. Sucesso! Mostra     │                       │
  │     calendários         │                       │
  │<─────────────────────────┤                       │
  │                         │                       │
```

---

## 🔍 Anatomia da URL de Redirect

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│  https://zapagenda.vercel.app/api/google/oauth/callback    │
│  └─┬──┘ └───────┬─────────────┘ └──────┬────────────────┘  │
│    │            │                       │                   │
│ Protocol     Domain                  Path                   │
│  (https)   (seu projeto)         (fixo no código)          │
│                                                              │
│  ⚠️ Deve estar EXATAMENTE assim no Google Console          │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Onde está definido?

No código (`/src/lib/google.ts`):

```typescript
function getRedirectUri() {
  const base = process.env.APP_BASE_URL.replace(/\/$/, "");
  return `${base}/api/google/oauth/callback`;
  //             └──────────────┬─────────────┘
  //                       Path fixo
}
```

**Por isso:**
- ✅ Configure `APP_BASE_URL` = `https://zapagenda.vercel.app`
- ✅ O código adiciona `/api/google/oauth/callback` automaticamente
- ✅ No Google Console, coloque a URL completa com o path

---

## 📊 Checklist Visual

```
Google Cloud Console:
┌─────────────────────────────────────────────┐
│ [✓] Criar projeto (se não existir)         │
│ [✓] Ativar Google Calendar API              │
│ [✓] Ativar Google+ API (userinfo.email)    │
│ [✓] Criar OAuth 2.0 Client ID               │
│     └─ Tipo: Aplicativo da Web              │
│ [✓] Adicionar Origens JavaScript            │
│     └─ https://zapagenda.vercel.app         │
│     └─ http://localhost:3000                │
│ [✓] Adicionar URIs de Redirecionamento      │
│     └─ .../api/google/oauth/callback        │
│ [✓] Copiar Client ID                        │
│ [✓] Copiar Client Secret                    │
└─────────────────────────────────────────────┘

Vercel Dashboard:
┌─────────────────────────────────────────────┐
│ [✓] Settings → Environment Variables        │
│ [✓] Adicionar GOOGLE_CLIENT_ID              │
│ [✓] Adicionar GOOGLE_CLIENT_SECRET          │
│ [✓] Adicionar APP_BASE_URL                  │
│ [✓] Marcar "Production"                     │
│ [✓] Redeploy (ou aguardar próximo deploy)  │
└─────────────────────────────────────────────┘

Teste:
┌─────────────────────────────────────────────┐
│ [✓] Aguardar 5-10 minutos                   │
│ [✓] Acessar /dashboard/configuracoes        │
│ [✓] Clicar "Conectar Google Calendar"       │
│ [✓] Autorizar na tela do Google             │
│ [✓] Verificar calendários listados          │
└─────────────────────────────────────────────┘
```

---

## 🎨 Tela de Consentimento (Opcional mas Recomendado)

```
🌐 URL: https://console.cloud.google.com/apis/credentials/consent
```

```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Tela de consentimento OAuth                                ┃
┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃
┃                                                             ┃
┃ Nome do app: DaTempo                                       ┃
┃                                                             ┃
┃ Logo do app: [📤 Upload logo DaTempo]                     ┃
┃                                                             ┃
┃ Email de suporte: seu-email@exemplo.com                    ┃
┃                                                             ┃
┃ Link da política de privacidade:                           ┃
┃ https://zapagenda.vercel.app/privacidade                   ┃
┃                                                             ┃
┃ Link dos termos de serviço:                                ┃
┃ https://zapagenda.vercel.app/termos                        ┃
┃                                                             ┃
┃ Escopos:                                                    ┃
┃ ✓ https://www.googleapis.com/auth/calendar                 ┃
┃ ✓ https://www.googleapis.com/auth/userinfo.email           ┃
┃                                                             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
```

---

*Guia Visual DaTempo 🕰️ - Outubro 2025*
