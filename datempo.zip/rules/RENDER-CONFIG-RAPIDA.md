# 🔐 Configuração EXATA das Variáveis de Ambiente no Render

## ✅ Credenciais Extraídas (COPIE E COLE)

### Vá em: https://dashboard.render.com
1. Selecione o serviço "zap-agenda"
2. Clique em **"Environment"** no menu lateral
3. Adicione ou verifique estas variáveis:

---

### 📝 Variáveis para Copiar e Colar:

#### 1. GOOGLE_CLIENT_ID
```
966992499199-54vvrq2q3rngcnrp3c1rilu4oj4cf3n2.apps.googleusercontent.com
```

#### 2. GOOGLE_CLIENT_SECRET
```
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
```

#### 3. GOOGLE_REDIRECT_URI
```
https://zap-agenda.onrender.com/api/google/oauth/callback
```

#### 4. APP_BASE_URL
```
https://zap-agenda.onrender.com
```

---

## 📸 Como Configurar (com screenshots mentais)

### Passo 1: Acesse o Render Dashboard
👉 https://dashboard.render.com

### Passo 2: Selecione seu Serviço
- Procure por "zap-agenda"
- Clique no card do serviço

### Passo 3: Vá em Environment
- No menu lateral esquerdo
- Clique em **"Environment"**

### Passo 4: Adicione as Variáveis
Para cada variável:
1. Clique em **"Add Environment Variable"**
2. Em **"Key"**, digite o nome (ex: `GOOGLE_CLIENT_ID`)
3. Em **"Value"**, cole o valor (copie deste documento)
4. Clique em **"Add"**

### Passo 5: Salvar e Redeploy
1. Depois de adicionar todas as 4 variáveis
2. Clique em **"Save Changes"**
3. O Render vai fazer **redeploy automático** (1-2 minutos)

---

## ✅ Checklist de Variáveis

Marque conforme for adicionando:

- [ ] `GOOGLE_CLIENT_ID` = `966992499199-54vvrq2q3rngcnrp3c1rilu4oj4cf3n2.apps.googleusercontent.com`
- [ ] `GOOGLE_CLIENT_SECRET` = `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`
- [ ] `GOOGLE_REDIRECT_URI` = `https://zap-agenda.onrender.com/api/google/oauth/callback`
- [ ] `APP_BASE_URL` = `https://zap-agenda.onrender.com`

---

## 🧪 Teste Após Configurar

### Teste 1: Verificar se as variáveis foram carregadas

Aguarde o redeploy terminar (1-2 min), depois:

```bash
# Teste se o app está rodando
curl https://zap-agenda.onrender.com/api/session

# Deve retornar algo como:
# {"user":null} ou {"user":{...}}
```

### Teste 2: Testar Conexão Google (após fazer login)

```bash
# Primeiro faça login no dashboard:
# https://zap-agenda.onrender.com/dashboard

# Depois teste:
curl https://zap-agenda.onrender.com/api/health/google
```

**Resposta esperada (SUCESSO)**:
```json
{
  "ok": true,
  "calendarsCount": 1
}
```

**Resposta se não conectou ainda**:
```json
{
  "error": "Google Calendar não conectado"
}
```

Se retornar erro, você precisa:
1. Ir em: https://zap-agenda.onrender.com/dashboard
2. Clicar em "Conectar Google Calendar"
3. Autorizar o acesso

### Teste 3: Criar Agendamento

1. Acesse: https://zap-agenda.onrender.com/agenda/[seu-slug]
2. Preencha o formulário
3. Clique em "Agendar"
4. Verifique no Google Calendar: https://calendar.google.com
5. O evento deve aparecer! 🎉

---

## 🔍 Verificar Logs do Render

Se algo der errado, veja os logs:

1. No Render Dashboard, clique no serviço
2. Clique em **"Logs"** (menu lateral)
3. Procure por:
   - ✅ `[apt:google:event:success]` - Evento criado com sucesso
   - ❌ `[apt:google:event:failed]` - Erro ao criar evento
   - ❌ `[google:event:create:error]` - Detalhes do erro

**Erros comuns:**
- `GOOGLE_CLIENT_ID is required` → Variável não configurada
- `invalid_client` → `CLIENT_SECRET` errado
- `redirect_uri_mismatch` → URI de callback diferente
- `Calendar API has not been used` → API não habilitada no Google Cloud

---

## 📊 Configuração Atual do Google Cloud

### ✅ O que já está configurado:

**Projeto**: `zapagenda-3e479`

**Client ID**: `966992499199-54vvrq2q3rngcnrp3c1rilu4oj4cf3n2.apps.googleusercontent.com`

**URIs de Redirecionamento**:
- ✅ `https://zapagenda-3e479.firebaseapp.com/__/auth/handler`
- ✅ `https://zap-agenda.onrender.com/api/google/oauth/callback`

**JavaScript Origins**:
- ✅ `http://localhost`
- ✅ `https://zapagenda-3e479.firebaseapp.com`
- ✅ `https://zap-agenda.onrender.com`

### ⚠️ O que ainda precisa verificar no Google Cloud:

Siga o guia: `GOOGLE-CLOUD-PROXIMAS-ACOES.md`

1. [ ] **Google Calendar API habilitada**
   - 👉 https://console.cloud.google.com/apis/library/calendar-json.googleapis.com
   
2. [ ] **Escopos do Calendar configurados**
   - 👉 https://console.cloud.google.com/apis/credentials/consent
   - Adicionar: `https://www.googleapis.com/auth/calendar`
   - Adicionar: `https://www.googleapis.com/auth/calendar.events`

3. [ ] **App publicado** (ou usuários de teste adicionados)
   - Se está "Em teste" → só 100 usuários
   - Se está "Em produção" → usuários ilimitados

4. [ ] **Nome do app mudado**
   - De: `project-966992499199`
   - Para: `ZapAgenda`

---

## 🎯 Ordem de Execução

### Faça NESTA ORDEM:

1. ✅ **Configurar variáveis no Render** (este guia) - 5 min
2. ⏳ **Aguardar redeploy** - 1-2 min
3. ✅ **Configurar Google Cloud Console** (veja `GOOGLE-CLOUD-PROXIMAS-ACOES.md`) - 10 min
4. ✅ **Fazer login no dashboard** - 1 min
5. ✅ **Conectar Google Calendar** - 2 min
6. ✅ **Testar agendamento** - 2 min

**Tempo total: ~20 minutos**

---

## 🆘 Problemas e Soluções

### Problema: "GOOGLE_CLIENT_ID is required"
**Causa**: Variável não foi configurada ou redeploy não terminou
**Solução**: 
1. Verifique se a variável foi adicionada
2. Aguarde o redeploy terminar
3. Recarregue a página

### Problema: "invalid_client"
**Causa**: `GOOGLE_CLIENT_SECRET` errado
**Solução**: Copie novamente do arquivo JSON (verifique se não tem espaços)

### Problema: "redirect_uri_mismatch"
**Causa**: URI de callback não bate
**Solução**: Verifique se `GOOGLE_REDIRECT_URI` é exatamente:
```
https://zap-agenda.onrender.com/api/google/oauth/callback
```

### Problema: "Error 403: access_denied"
**Causa**: App em modo teste e usuário não está na lista
**Solução**: 
1. Vá em: https://console.cloud.google.com/apis/credentials/consent
2. Adicione o email em "Usuários de teste"
3. OU clique em "PUBLICAR APLICATIVO"

---

## ✅ Confirmação Final

Depois de configurar TUDO, execute este teste:

```bash
# 1. Verifique se o app está rodando
curl https://zap-agenda.onrender.com

# 2. Faça login no dashboard
# Vá em: https://zap-agenda.onrender.com/dashboard

# 3. Conecte o Google Calendar
# Clique no botão "Conectar Google Calendar"

# 4. Teste o health check
curl https://zap-agenda.onrender.com/api/health/google

# 5. Faça um agendamento de teste
# Vá em: https://zap-agenda.onrender.com/agenda/[seu-slug]

# 6. Verifique no Google Calendar
# Vá em: https://calendar.google.com
```

**Se todos os passos funcionarem, PARABÉNS! 🎉**
**Seu ZapAgenda está 100% operacional com Google Calendar sync!**

---

## 📞 Precisa de Ajuda?

Se encontrar algum erro:
1. Veja os logs do Render
2. Veja o troubleshooting: `TROUBLESHOOTING-AGENDAMENTO.md`
3. Veja a checklist: `GOOGLE-CLOUD-CHECKLIST.md`
4. Ou peça ajuda com o print do erro! 🚀
