import { PageLoader } from '@/components/loading';

export default function LoginLoading() {
  return <PageLoader message="Preparando o acesso..." />;
}
