import { PageLoader } from '@/components/loading';

export default function MinhaAgendaLoading() {
  return <PageLoader message="Organizando seus calendários..." />;
}
