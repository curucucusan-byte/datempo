import { PageLoader } from '@/components/loading';

export default function DashboardLoading() {
  return <PageLoader message="Preparando sua escrivaninha..." />;
}
