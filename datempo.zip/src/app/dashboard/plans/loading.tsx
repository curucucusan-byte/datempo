import { PageLoader } from '@/components/loading';

export default function PlansLoading() {
  return <PageLoader message="Carregando os planos..." />;
}
