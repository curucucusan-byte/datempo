import { PageLoader } from '@/components/loading';

export default function Loading() {
  return <PageLoader message="Só um instantinho, dá tempo! ☕" />;
}
