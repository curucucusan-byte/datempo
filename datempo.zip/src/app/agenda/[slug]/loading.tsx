import { PageLoader } from '@/components/loading';

export default function AgendaLoading() {
  return <PageLoader message="Carregando agendamento..." />;
}
