export default function robots() {
  return { rules: [{ userAgent: "*" }], sitemap: "https://seu-dominio.vercel.app/sitemap.xml" };
}
