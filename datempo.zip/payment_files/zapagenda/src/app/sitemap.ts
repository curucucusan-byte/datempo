export default function sitemap() {
  return [{ url: "https://seu-dominio.vercel.app", lastModified: new Date() }];
}
