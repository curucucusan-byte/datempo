// Caminho do arquivo: /home/ubuntu/zapagenda/zapagenda/src/app/api/webhooks/stripe/route.ts

import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { updatePaymentStatus, updateSubscriptionStatus } from "@/lib/payments";

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(request: NextRequest) {
  try {
    const body = await request.text();
    const signature = request.headers.get("stripe-signature")!;

    let event;
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
    } catch (err) {
      console.error("Webhook signature verification failed:", err);
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
    }

    switch (event.type) {
      case "payment_intent.succeeded":
        const paymentIntent = event.data.object;
        await updatePaymentStatus(
          paymentIntent.id,
          "succeeded",
          new Date().toISOString()
        );
        break;

      case "payment_intent.payment_failed":
        const failedPayment = event.data.object;
        await updatePaymentStatus(failedPayment.id, "failed");
        break;

      case "customer.subscription.updated":
      case "customer.subscription.created":
        const subscription = event.data.object;
        await updateSubscriptionStatus(
          subscription.id,
          subscription.status as any,
          subscription.current_period_start,
          subscription.current_period_end,
          subscription.cancel_at_period_end
        );
        break;

      case "customer.subscription.deleted":
        const deletedSub = event.data.object;
        await updateSubscriptionStatus(deletedSub.id, "canceled");
        break;

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook error:", error);
    return NextResponse.json({ error: "Webhook error" }, { status: 500 });
  }
}
