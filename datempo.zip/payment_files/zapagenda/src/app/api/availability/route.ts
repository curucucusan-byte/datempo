// Caminho do arquivo: /home/ubuntu/zapagenda/zapagenda/src/app/api/availability/route.ts

import { NextResponse } from "next/server";

// import { getProfessional, resolveProfessional, getServiceMinutes } from "@/lib/professionals"; // Removido
import { loadAppointments } from "@/lib/store";
import { getAccount } from "@/lib/account";
import { freeBusyForDate, getLinkedCalendarBySlug } from "@/lib/google"; // Adicionado getLinkedCalendarBySlug

const WEEKDAYS = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
] as const;

type WeekdayKey = (typeof WEEKDAYS)[number];

type AvailabilityResult = {
  ok: true;
  date: string;
  slotMinutes: number;
  free: string[];
  taken: { start: string; end: string }[];
};

type ErrorResult = {
  ok: false;
  error: string;
};

function overlaps(aStart: Date, aEnd: Date, bStart: Date, bEnd: Date) {
  return aStart < bEnd && bStart < aEnd;
}

function parseDateOnly(date: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const [year, month, day] = date.split("-").map(Number);
  if (!year || !month || !day) return null;
  const utc = Date.UTC(year, month - 1, day);
  return { year, month, day, utcDate: new Date(utc) };
}

function toUtcIso(dateParts: { year: number; month: number; day: number }, time: string) {
  const [hourStr, minuteStr] = time.split(":");
  const hour = Number(hourStr);
  const minute = Number(minuteStr);
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) {
    return null;
  }
  const { year, month, day } = dateParts;
  const ts = Date.UTC(year, month - 1, day, hour, minute);
  return new Date(ts);
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const slug = searchParams.get("slug");
  const date = searchParams.get("date");
  // const service = searchParams.get("service") ?? undefined; // Removido

  if (!slug) {
    return NextResponse.json<ErrorResult>(
      { ok: false, error: "Informe o slug da agenda (?slug=)." }, // Mensagem atualizada
      { status: 400 }
    );
  }

  if (!date) {
    return NextResponse.json<ErrorResult>(
      { ok: false, error: "Informe a data desejada (?date=YYYY-MM-DD)." },
      { status: 400 }
    );
  }

  const parsedDate = parseDateOnly(date);
  if (!parsedDate) {
    return NextResponse.json<ErrorResult>(
      { ok: false, error: "Data inválida. Use o formato YYYY-MM-DD." },
      { status: 400 }
    );
  }

  // let professional = getProfessional(slug); // Removido
  // if (!professional) { // Removido
  //   professional = await resolveProfessional(slug); // Removido
  // } // Removido
  // if (!professional) { // Removido
  //   return NextResponse.json<ErrorResult>({ ok: false, error: "Profissional não encontrado." }, { status: 404 }); // Removido
  // } // Removido

  const linkedCalendar = await getLinkedCalendarBySlug(slug); // Usar nova função
  if (!linkedCalendar) {
    return NextResponse.json<ErrorResult>({ ok: false, error: "Agenda não encontrada." }, { status: 404 });
  }

  // const fallbackMinutes = professional.services?.[0]?.minutes ?? 60; // Removido
  // const slotMinutes = Math.max(
  //   5,
  //   getServiceMinutes(professional, service ?? "", fallbackMinutes)
  // ); // Removido
  const slotMinutes = 60; // Duração padrão de 60 minutos, ou pode ser configurável na agenda

  // Definição de slots base: preferimos Google Calendar.
  const ownerUid = linkedCalendar.ownerUid ?? null; // Usar ownerUid da agenda
  let googleBusy: { start: string; end: string }[] | null = null;
  let daySlots: string[] = [];
  if (ownerUid) {
    const account = await getAccount(ownerUid);
    const calId = linkedCalendar.id; // Usar o ID da agenda vinculada
    if (calId) {
      googleBusy = await freeBusyForDate(ownerUid, calId, date);
    }
  }

  if (googleBusy) {
    // Gera slots de 08:00 até 20:00 pelo tamanho do serviço
    const startHour = 8;
    const endHour = 20;
    for (let h = startHour; h < endHour; h++) {
      for (let m = 0; m < 60; m += slotMinutes) {
        const hh = String(h).padStart(2, "0");
        const mm = String(m).padStart(2, "0");
        daySlots.push(`${hh}:${mm}`);
      }
    }
  } else {
    // Fallback simples 09:00–18:00, caso sem Google
    for (let h = 9; h < 18; h++) {
      const hh = String(h).padStart(2, "0");
      daySlots.push(`${hh}:00`);
      if (slotMinutes <= 30) daySlots.push(`${hh}:30`);
    }
  }

  const appointments = await loadAppointments();
  const dayAppointments = appointments.filter((appt) => {
    if (appt.slug !== slug) return false;
    return appt.startISO.slice(0, 10) === date;
  });

  const free: string[] = [];
  for (const time of daySlots) {
    const slotStart = toUtcIso(parsedDate, time);
    if (!slotStart) continue;
    const slotEnd = new Date(slotStart.getTime() + slotMinutes * 60_000);

    const hasLocalClash = dayAppointments.some((appt) =>
      overlaps(slotStart, slotEnd, new Date(appt.startISO), new Date(appt.endISO))
    );
    const hasGoogleClash = (googleBusy ?? []).some((b) =>
      overlaps(slotStart, slotEnd, new Date(b.start), new Date(b.end))
    );

    if (!hasLocalClash && !hasGoogleClash) {
      free.push(slotStart.toISOString());
    }
  }

  const taken = dayAppointments
    .map((appt) => ({ start: appt.startISO, end: appt.endISO }))
    .sort((a, b) => a.start.localeCompare(b.start));

  const result: AvailabilityResult = {
    ok: true,
    date,
    slotMinutes,
    free,
    taken,
  };

  return NextResponse.json(result);
}

