import { SESSION_COOKIE } from "@/lib/session";

export function getSessionCookieName() {
  return SESSION_COOKIE;
}
