// Caminho do arquivo: /home/ubuntu/zapagenda/zapagenda/src/lib/professionals.ts
// Este arquivo foi removido conforme as novas diretrizes. O conceito de 'Profissional' não existe mais.

